#ifndef PIP_H
#define PIP_H
#include "test.h"
#define FIFO_WRITE "serial_in"  // 主程序读取命令的管道
#define FIFO_READ "serial_out"  // 主程序发送数据的管道

extern int qt_fd;
void pip_init();


#endif 