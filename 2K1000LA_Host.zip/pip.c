#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <fcntl.h>
#include <termios.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <pthread.h>
#include <errno.h>
#include "test.h"
#include "pip.h"

int qt_fd;

void pip_init() 
{
    if (access("arr_send", F_OK) == -1)
    {
        // 管道文件不存在
        // 创建命名管道
        int res = mkfifo("arr_send", 0666);
        if (res != 0)
        {
            printf("Could not create fifo arr_send");
            exit(EXIT_FAILURE);
        }
    }

    qt_fd = open("arr_send", O_WRONLY);
    if (qt_fd == -1) {
        perror("打开FIFO失败");
        
    }  
}

