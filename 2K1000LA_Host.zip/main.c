#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <fcntl.h>
#include <termios.h>
#include "queue.h"
#include "serial.h"
#include "gpio.h"
#include "mmap_reg.h"
#include "test.h"
#include "ZigBee.h"
#include <pthread.h>
#include <errno.h>
#include "mqtt.h"
#include <time.h>
#include "mqttclient.h"

//REFLCT
unsigned char *mmap_reg_1;
unsigned char *mmap_reg_2;
pthread_mutex_t queue_mutex = PTHREAD_MUTEX_INITIALIZER;  // 静态初始化
int dev_fd; 

uint8_t Read_Buffer[255]; 
uint8_t Read_length;
uint8_t arr[11] = {0xAA, 0xAB, 0, 0, 0, 0, 0, 0, 0, 0, 0xBB};

int fd1;
int counter = 0;
const int upload_interval = 20;  // 100ms * 50 = 5秒

////////////////////////////////////////////////////////////////////
void signal_handler(int signum) 
{
    if (signum == SIGIO) 
    {
        uint8_t rcv_buf[128];
        int receive_count = read(fd1, rcv_buf, sizeof(rcv_buf));
        
        if (receive_count > 0) 
        {    
            for (int i = 0; i < receive_count; i++) 
            {
                pthread_mutex_lock(&queue_mutex);
                Queue_Wirte(&Circular_queue, &rcv_buf[i], 1);  // 修正拼写
                pthread_mutex_unlock(&queue_mutex);
            }
        } 
        else if (receive_count == -1 && errno != EAGAIN) 
        {
            perror("Error reading from UART");
        }
    }
}

////////////////////////////////////////////////////////////////////

int main ()
{	

    static uint16_t temp = 1; 
    static uint16_t humi = 1;
    static uint16_t Flame1 = 1;
    static uint16_t Flame2 = 1;
    static uint16_t rain = 1;
    static uint16_t PRESS_AO =1;
    static uint16_t UV_index = 1;
    static uint16_t distance = 1;
    //queue init
    Queue_Init(&Circular_queue);
    //mqtt init
    mqtt_init();
    //open  uart 
	fd1=open("/dev/ttyS1", O_RDWR | O_NOCTTY);//fd1 receive
    signal(SIGIO, signal_handler);
    fcntl(fd1, F_SETOWN, getpid());
    fcntl(fd1, F_SETFL, FASYNC | O_NONBLOCK);
    uart_init(fd1,B9600,8,"1",'N',0,1);

    //init
    mmap_reg_1 = NULL;
    mmap_reg_2 = NULL;	
    init_mmap_reg();
	
    //shuang xian mo shi
    gpio_model_set(0,1,1,mmap_reg_1);
  	gpio_model_set(1,1,1,mmap_reg_1);
   	gpio_model_set(2,1,1,mmap_reg_1);
    gpio_model_set(3,1,1,mmap_reg_1);// 正确传递指针的方式
    DL_LN3X_Init(DL_LN3X_NODE, CHANNEL, Network1_Id);    

    delay_ms(100);
	while (1)
{
    pthread_mutex_lock(&queue_mutex);
    if (!Queue_isEmpty(&Circular_queue)) 
    {
        Read_length = Queue_HadUse(&Circular_queue);
        if (Read_length <= sizeof(Read_Buffer)) 
        {
            Queue_Read(&Circular_queue, Read_Buffer, Read_length);
			if (Read_Buffer[6] == 0x02)
			{
				temp = Read_Buffer[7] << 8 | Read_Buffer[8];
				humi = Read_Buffer[9] << 8 | Read_Buffer[10];
				PRESS_AO = Read_Buffer[11] << 8 | Read_Buffer[12];
			}
			
			else if (Read_Buffer[6] == 0x03)
			{
				UV_index = Read_Buffer[7] << 8 | Read_Buffer[8];
				distance = Read_Buffer[9] << 8 | Read_Buffer[10];
				Flame1 = Read_Buffer[11] << 8 | Read_Buffer[12];
			}
			
			else if (Read_Buffer[6] == 0x04)
			{
				rain = Read_Buffer[7] << 8 | Read_Buffer[8];
				Flame2 = Read_Buffer[9] << 8 | Read_Buffer[10];
			}

            // 准备数据数组并发送
			arr[0] = 0xAA;
			arr[1] = 0xAB;
			arr[2] = temp / 10;
			arr[3] = humi / 10;
			arr[4] = Flame1;
			arr[5] = Flame2;
			arr[6] = UV_index;
			arr[7] = PRESS_AO;
			arr[8] = rain;
			arr[9] = distance;
			arr[10] = 0xBB;
            
            
            /*for(int i = 0; i < 11; i++) 
            {
                printf("arr[%d] = 0x%02X\n", i, arr[i]);
            }*/


            if ((++counter >= upload_interval)&&arr[2]!=0x19) 
            {
                Mqtt_Upload(arr);
                counter = 0;
            }

            if (mqtt_is_connected(client)==2) 
            {
                Matt_reconnect();
            }   
            
        } 
    }
    memset(Read_Buffer, 0, 255);
    
    pthread_mutex_unlock(&queue_mutex);
    delay_ms(50);  // 减少延迟时间
}
return 1;
}



