#ifndef GPIO_H
#define GPIO_H

#define REG_BASE        0x1fe00000
#define GPIO_EN         0x500
#define GPIO_OUT        0x510
#define GPIO_IN         0x520

int gpio_enable(int gpio_num, int val, char *map_base);
int gpio_close(char *map_base);
int gpio_write(int gpio, int val, char *map_base);
int gpio_read(int gpio_num, char *map_base);
int gpio_model_set(int bit_num, int val, int reg, unsigned char *map_base);

void delay_us(unsigned int us);
void delay_ms(unsigned int ms);

#define MODEL_SET_0_7   0x420
#define MODEL_SET_8_15  0x421
#define MODEL_SET_16_23 0x422
#define MODEL_SET_24_31 0x423
#define MODEL_SET_32_39 0x424
#define MODEL_SET_40_47 0x425
#define MODEL_SET_48_55 0x426
#define MODEL_SET_56_63 0x427

#endif // GPIO_H
