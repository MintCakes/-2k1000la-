#ifndef __TEST_H__
#define __TEST_H__

typedef unsigned char bool;  
typedef unsigned char BOOL;
typedef unsigned char INT8U;
typedef signed char INT8S;
typedef unsigned short INT16U;
typedef signed short INT16S;
typedef unsigned int INT32U; //32位
typedef signed int INT32S;
typedef unsigned long long INT64U; //64位
typedef signed long long INT64S;
typedef float FP32;
typedef float FP64;
typedef unsigned int  const   ucint32_t;  /* Read Only */
typedef unsigned short const  ucint16_t;  /* Read Only */
typedef unsigned char  const  ucint8_t;   /* Read Only */
typedef unsigned int   uint32_t;
typedef unsigned char  uchar_t;
typedef unsigned char  uint8_t;
typedef unsigned short uint16_t;
typedef volatile unsigned int   vuint32_t;
typedef volatile unsigned short vuint16_t;
typedef volatile unsigned char  vuint8_t;
    
#endif

