#ifndef MMAP_REG_H
#define MMAP_REG_H

#define MAP_SIZE        0x10000
#include <sys/mman.h>

#define REG_BASE_1    0x1fe00000
#define REG_BASE_2    0x1fe10000


//unsigned char uint8_t mmap_reg_1;
//unsigned char uint8_t mmap_reg_2;
void init_mmap_reg();
#endif 

