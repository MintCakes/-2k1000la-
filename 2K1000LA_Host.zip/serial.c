/*
 * Program:     serial.c
 * Author:      Paul Dean
 * Version:     0.0.3
 * Date:        2002-02-19
 * Description: To provide underlying serial port function,
 *              for high level applications.
 *
*/

#include <sys/time.h>
#include <sys/types.h>
#include <string.h>
#include <stdlib.h>
#include <sys/select.h>
#include <termios.h>            /* tcgetattr, tcsetattr */
#include <stdio.h>              /* perror, printf, puts, fprintf, fputs */
#include <unistd.h>             /* read, write, close */
#include <fcntl.h>              /* open */
#include <sys/signal.h>           
#include <limits.h>  
#include "queue.h"
#include "serial.h"
#include "test.h"
#include <errno.h>

#define CHUNK_SIZE 256
/* set serial port baudrate by use of file descriptor fd */
static void set_baudrate (struct termios *opt, unsigned int baudrate)
{
	cfsetispeed(opt, baudrate);
	cfsetospeed(opt, baudrate);
}

static void set_data_bit (struct termios *opt, unsigned int databit)
{
    opt->c_cflag &= ~CSIZE;
    switch (databit) {
    case 8:
        opt->c_cflag |= CS8;
        break;
    case 7:
        opt->c_cflag |= CS7;
        break;
    case 6:
        opt->c_cflag |= CS6;
        break;
    case 5:
        opt->c_cflag |= CS5;
        break;
    default:
        opt->c_cflag |= CS8;
        break;
    }
}

static void set_stopbit (struct termios *opt, const char *stopbit)
{
    if (0 == strcmp (stopbit, "1")) {
        opt->c_cflag &= ~CSTOPB; /* 1 stop bit */
    }	else if (0 == strcmp (stopbit, "1")) {
        opt->c_cflag &= ~CSTOPB; /* 1.5 stop bit */
    }   else if (0 == strcmp (stopbit, "2")) {
        opt->c_cflag |= CSTOPB;  /* 2 stop bits */
    } else {
        opt->c_cflag &= ~CSTOPB; /* 1 stop bit */
    }
}

static void set_parity (struct termios *opt, char parity)
{
    switch (parity) {
    case 'N':                  /* no parity check */
        opt->c_cflag &= ~PARENB;
        break;
    case 'E':                  /* even */
        opt->c_cflag |= PARENB;
        opt->c_cflag &= ~PARODD;
        break;
    case 'O':                  /* odd */
        opt->c_cflag |= PARENB;
        opt->c_cflag |= ~PARODD;
        break;
    default:                   /* no parity check */
        opt->c_cflag &= ~PARENB;
        break;
    }
}


int set_port_attr(int fd, int baudrate, int databit, 
    const char *stopbit, char parity, int vtime, int vmin) {
struct termios opt;
tcgetattr(fd, &opt);

// 关键配置
opt.c_cflag |= CLOCAL | CREAD;  // 必须启用本地连接和接收使能
opt.c_lflag &= ~(ICANON | ECHO | ISIG); // 非规范模式，关闭回显和信号
opt.c_iflag &= ~(IXON | IXOFF | IXANY); // 关闭流控
opt.c_oflag &= ~OPOST;          // 原始输出模式

// 设置 VMIN 和 VTIME
opt.c_cc[VMIN] = vmin;  // 触发条件：每接收 vmin 字节
opt.c_cc[VTIME] = vtime; // 超时时间（单位：0.1秒）

// 其他设置（波特率、数据位等）
set_baudrate(&opt, baudrate);
set_data_bit(&opt, databit);
set_parity(&opt, parity);
set_stopbit(&opt, stopbit);

tcflush(fd, TCIFLUSH);
return tcsetattr(fd, TCSANOW, &opt);
}


int uart_init(int fd,int  baudrate,int  databit,const char *stopbit,char parity,int vtime,int vmin)
{
    static uint8_t which=1;
	if(set_port_attr (fd,baudrate,databit,stopbit,parity,vtime,vmin)<0) {
		printf("set uart%d arrt faile \n",which);
		exit(-1);
	}
    tcflush(fd,TCIOFLUSH);
    which++;
    return 0;
}


/*int uart_read(int fd, int timeout)
{
    int receive_count;
    fd_set fs_read;
    int fs_sel;              //recive flag
    struct timeval time;      //
    time.tv_sec = timeout / 1000;
    time.tv_usec = timeout % 1000 * 1000;
    FD_ZERO(&fs_read); // 清空串口接收端口集
    FD_SET(fd, &fs_read); // 设置串口接收端口集
    fs_sel = select(fd + 1, &fs_read,NULL, NULL, &time);
    if (fs_sel)
    {
        uint8_t rcv_buf[100];
        receive_count = read(fd, rcv_buf, sizeof(rcv_buf));
        for (int i = 0; i < receive_count; i++)
        {
            Queue_Wirte(&Circular_queue, rcv_buf, 1);

        }
        printf("Iv read %d bytes from test.txt, as bellow:\n", receive_count);
        printf("%s\n", rcv_buf);
    }
}*/



int uart_send(int fd, uint8_t *buf, size_t buf_size) {
    ssize_t bytes_written;
    size_t total_bytes_sent = 0;

    // 检查文件描述符是否有效
    if (fd == -1) {
        perror("Invalid file descriptor");
        return -1;
    }

    while (total_bytes_sent < buf_size) {
        size_t remaining_bytes = buf_size - total_bytes_sent;
        size_t chunk_size = (remaining_bytes > CHUNK_SIZE) ? CHUNK_SIZE : remaining_bytes;

        // 使用 write 系统调用发送数据
        bytes_written = write(fd, buf + total_bytes_sent, chunk_size);
        if (bytes_written == -1) {
            perror("Failed to write to UART");
            return -1;
        }

        total_bytes_sent += bytes_written;

        // 检查写入的字节数是否与预期一致
        if ((size_t)bytes_written != chunk_size) {
            fprintf(stderr, "Incomplete write: %zd bytes written instead of %zu\n", bytes_written, chunk_size);
            return -1;
        }
    }

    return 0; // 成功发送数据
}

int uart_sendByte(int fd, uint8_t data) 
{
    uint8_t  len;
    len = write(fd, &data, 1);  // 关键修改点：发送单个字节
    
    if (len != 1) 
    {             // 检查是否成功写入1个字节
        printf("write data error \n");
        return -1;
    }
    return 0;  // 成功返回0
}





