#ifndef _SERIAL_H
#define _SERIAL_H 

//void set_baudrate (struct termios *opt, unsigned int baudrate);
//void set_data_bit (struct termios *opt, unsigned int databit);
//void set_stopbit (struct termios *opt, const char *stopbit);
//void set_parity (struct termios *opt, char parity);

int set_port_attr(int fd,int  baudrate,int  databit,const char *stopbit,char parity,int vtime,int vmin);
int uart_send(int fd,  uint8_t *buf, size_t buf_size);
int uart_init(int fd,int  baudrate,int  databit,const char *stopbit,char parity,int vtime,int vmin);
int uart_sendByte(int fd, uint8_t data);
#endif

