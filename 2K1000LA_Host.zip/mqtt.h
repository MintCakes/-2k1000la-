#ifndef MQTT_H
#define MQTT_H

#include "EasyMqtt.h"

// 声明全局MQTT客户端
extern EasyMqttClient_t *client;

void Mqtt_Upload(unsigned char *JsonData);
void mqtt_init();
void Matt_reconnect();

#endif 