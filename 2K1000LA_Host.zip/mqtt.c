#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>
#include <pthread.h>
#include <sys/time.h>
#include "EasyMqtt.h"  
#include <test.h>


#define CLIENT_ID "d06a1cbaf205872969d3718e8955ee73"
#define USERNAME "bkrc"
#define PASSWORD "88888888"

#define MQTT_ADDRESS "115.28.209.116"
#define MQTT_PORT 1883
#define TOPIC_REPORT "device/15a7907ed7707e0a/up"
#define TOPIC_COMMANDS "device/15a7907ed7707e0a/down"

typedef struct mqtt_client mqtt_client_t;
typedef mqtt_client_t* MqttClient; 
EasyMqttClient_t *client = NULL;
int data_temp = 1;
pthread_mutex_t mqtt_mutex = PTHREAD_MUTEX_INITIALIZER;


void mqtt_callback(const char *topic, char* data, unsigned short len) {

    printf("Received MQTT message on topic %s: %.*s\n", topic, len, data);
    
}

// 初始化MQTT
void mqtt_init() {
    // 1. 配置MQTT属性
    EasyMqttAttr_t attr = {
        .Url = MQTT_ADDRESS,        // MQTT服务器地址
        .Port = "1883",             // 端口号（字符串形式）
        .ClientId = CLIENT_ID,      // 客户端ID
        .Username = USERNAME,       // 用户名
        .Password = PASSWORD        // 密码
    };
    
    // 2. 创建MQTT客户端
    client = EasyMqttInit(&attr);
    if (!client) {
        printf("MQTT initialization failed!\n");
        exit(1);
    }
    
    // 3. 连接服务器
    if (EasyMqttConnect(client) != 0) {
        printf("MQTT connection failed!\n");
        EasyMqttUnInit(client);
        client = NULL;
        exit(1);
    }
    
    if (EasyMqttSubscribe(client, TOPIC_COMMANDS, EASY_QOS1, mqtt_callback) != 0) {
        printf("Subscription failed!\n");
    
    printf("MQTT connected and subscribed\n");
    }
}

// 数据上报函数
void Mqtt_Upload(unsigned char *JsonData) {
    char payload[512] = {0};

    snprintf(payload, sizeof(payload),
    "{\"sign\":\"15a7907ed7707e0a\","
    "\"type\":3,"
    "\"data\":{"
        "\"NodeOne\":{\"Temp\":%d,\"Humi\":%d},"  
        "\"NodeTwo\":{\"flame1\":%d,\"flame2\":%d}," 
        "\"NodeThree\":{\"UV_index\":%d,\"Fs\":%d},"  
        "\"NodeFour\":{\"Liqu\":%d,\"Distance\":%d}" 
    "}}",  
    JsonData[2], JsonData[3],
    JsonData[4], JsonData[5], 
    JsonData[6], JsonData[7], 
    JsonData[8], JsonData[9]);
    

    pthread_mutex_lock(&mqtt_mutex);
    EasyMqttPublish(client, TOPIC_REPORT, EASY_QOS1, payload, strlen(payload));;
    pthread_mutex_unlock(&mqtt_mutex);
    printf("Published: %s\n", payload);
}


void Matt_reconnect() {

    int success = 0;
    
    for (int attempt = 1; attempt <= 3; attempt++) {
        if (EasyMqttConnect(client) == 0) {
            EasyMqttSubscribe(client, TOPIC_COMMANDS, EASY_QOS1, mqtt_callback);
            printf("Reconnected after %d attempt(s)\n", attempt);
            success = 1;
            break; // 关键：成功时跳出循环
        }
        if (attempt < 3) {
            printf("Attempt %d failed, retrying...\n", attempt);
            sleep(2); // 仅失败时需要等待
        }
    }

    if (!success) {
        printf("Reconnect failed after 3 attempts\n");
        mqtt_init();
    }
}





    

