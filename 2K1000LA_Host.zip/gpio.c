#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <fcntl.h>
#include <unistd.h> 
#include <sys/mman.h>
#include <sys/time.h>
#include "gpio.h"
#include "test.h"
#include "mmap_reg.h"


extern int dev_fd;
//unsigned char *map_base=NULL;
//int dev_fd;


/*int gpio_init(void)
{	
	dev_fd = open("/dev/mem", O_RDWR | O_SYNC);      
	if (dev_fd < 0)  
	{
		printf("\nopen(/dev/mem) failed.\n");    
		return -1;
	}
	map_base=(unsigned char *)mmap(0,MAP_SIZE,PROT_READ|PROT_WRITE,MAP_SHARED,dev_fd,REG_BASE);
	return 0;

}*/
int gpio_enable(int gpio_num, int val, char *map_base)
{	int offset,gpio_move;                    
	if(gpio_num > 31) 
	{
		offset = 4;
		gpio_move = gpio_num- 32;
	} 
	else 
	{
		offset = 0;
		gpio_move = gpio_num;
	}
	if(val==0)
	{
		*(volatile unsigned int *)(map_base + GPIO_EN  +offset) |= (1<<gpio_move);         //GPIO使能in
		//printf("Enable GPIO%d in\n",gpio_num);
	}
	else
	{
		*(volatile unsigned int *)(map_base + GPIO_EN  +offset) &= ~(1<<gpio_move);         //GPIO使能out
		//printf("Enable GPIO%d out\n",gpio_num);
	}

	return 0;
}
int gpio_close(char *map_base)
{	
  
	if (dev_fd < 0)  
	{
		printf("\nopen(/dev/mem) failed.\n");    
		return -1;
	}

	munmap(map_base,MAP_SIZE);//解除映射关系
	if(dev_fd)
	{
		close(dev_fd);
	}
	return 0;
}



int gpio_write(int gpio_num, int val,char *map_base)
{
	int offset=0;
	int gpio_move=0;

	if(gpio_num > 31) 
	{
		offset = 4;
		gpio_move = gpio_num- 32;
	} 
	else 
	{
		offset = 0;
		gpio_move = gpio_num;
	}
	if(val == 1)
	{
		*(volatile unsigned int *)(map_base + GPIO_OUT +offset) |= (1<<gpio_move);     //输出高
	}
	else
	{
		*(volatile unsigned int *)(map_base + GPIO_OUT +offset) &= ~(1<<gpio_move);    //输出低
	}
	return 0;
}


int gpio_read(int gpio_num,char *map_base)
{
	int offset=0;
	int gpio_move=0;

	if(gpio_num > 31) 
	{
		offset = 4;
		gpio_move = gpio_num - 32;
	} 
	else 
	{
		offset = 0;
		gpio_move = gpio_num;
	}

	return (*(volatile unsigned int *)(map_base + GPIO_IN +offset) >> gpio_move) & 0x01;     //读取
}


int gpio_model_set(int bit_num, int val, int reg, unsigned char *map_base)
{
    int offset=0;
	int gpio_move=0;  // 修正了变量声明中的多余逗号

    // 根据 bit_num 确定基础 offset 和 gpio_move
    if (bit_num < 8) {
        offset = MODEL_SET_0_7;
        gpio_move = bit_num;
    } else if (bit_num < 16) {
        offset = MODEL_SET_8_15;
        gpio_move = bit_num - 8;
    } else if (bit_num < 24) {
        offset = MODEL_SET_16_23;
        gpio_move = bit_num - 16;
    } else if (bit_num < 32) {
        offset = MODEL_SET_24_31;
        gpio_move = bit_num - 24;
    } else if (bit_num < 40) {
        offset = MODEL_SET_32_39;
        gpio_move = bit_num - 32;
    } else if (bit_num < 48) {
        offset = MODEL_SET_40_47;
        gpio_move = bit_num - 40;
    } else if (bit_num < 56) {
        offset = MODEL_SET_48_55;
        gpio_move = bit_num - 48;
    } else if (bit_num < 64) {
        offset = MODEL_SET_56_63;
        gpio_move = bit_num - 56;
    }

    // 根据 param 调整 offset
    switch (reg) {
        case 1:
            offset += 0x008;     // param=1 时 offset 增加 0x008
            break;
        case 2:
            offset += 0x008 * 2; // param=2 时 offset 增加 0x010
            break;
        default:                // param=0 或其他值时保持 offset 不变
            break;
    }

    // 操作寄存器
    if (val == 1) {
        *(volatile unsigned int*)(map_base + offset) |= (1 << gpio_move);   // 置1
    } else {
        *(volatile unsigned int*)(map_base + offset) &= ~(1 << gpio_move); // 置0
    }

    return 0;
}






/****************************************************************************** 
 * 延时程序 
 */
struct timeval start_time , end_time;

void delay_us(unsigned int us)
{	
	int i = 0;
	gettimeofday(&start_time,NULL);
	end_time=start_time;
	while(1)
	{	
		if((end_time.tv_usec-start_time.tv_usec)<us)
		{
			gettimeofday(&end_time,NULL);
			i++;
		}
		else
		{
			break;
		}
		if(i>1000)
		{
			break;	
		}
		
	}
}

/*
 * 延时 1ms
 *
 * TODO 换算 TICKS_PER_SECOND
 */
void delay_ms(unsigned int ms)
{
	int i = 0;
	int us = ms*1000;
	gettimeofday(&start_time,NULL);
	end_time=start_time;
	while(1)
	{	
		if((end_time.tv_usec-start_time.tv_usec)<us)
		{
			gettimeofday(&end_time,NULL);
			i++;
		}
		else
		{
			break;
		}
		if(i>1000000)
		{
			break;	
		}
		
	}
}
