#include "mmap_reg.h"
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
#include "test.h"
extern unsigned char *mmap_reg_1;
extern unsigned char *mmap_reg_2;
extern int dev_fd;

void init_mmap_reg() {
    dev_fd = open("/dev/mem", O_RDWR | O_SYNC);
    if (dev_fd < 0) {
        printf("open failed");
    }

    mmap_reg_1 = (unsigned char *)mmap(0, MAP_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, dev_fd, REG_BASE_1);
    if (mmap_reg_1 == MAP_FAILED) {
        printf("reg_base_1 mmap failed");
    }

    mmap_reg_2 = (unsigned char*)mmap(0, MAP_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, dev_fd, REG_BASE_2);
    if (mmap_reg_2 == MAP_FAILED) {
        printf("reg_base_2 mmap failed");
    }
}
