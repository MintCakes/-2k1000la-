#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
#include "test.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <linux/videodev2.h>
#include <sys/ioctl.h>
int main()
{
    int fd = open("/dev/video1", O_RDWR);
    if (fd < 0) 
    {
        perror("Open video1");
        return -1;
    }

    struct v4l2_fmtdesc v4fmt;
    struct v4l2_capability cap;
    v4fmt.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;	//选择视频抓取
	int i = 0;
	while(1)
	{
		v4fmt.index = i;
		i++;
		int ret = ioctl(fd, VIDIOC_ENUM_FMT, &v4fmt);
		if(ret < 0)
		{
			perror("获取格式失败");
			break;
		}
		printf("index = %d\n", v4fmt.index);
		printf("flags = %d\n", v4fmt.flags);
		printf("descrrption = %s\n", v4fmt.description);
		unsigned char *p = (unsigned char*)&v4fmt.pixelformat;
		printf("pixelformat = %c%c%c%c\n", p[0],p[1],p[2],p[3]);
		printf("reserved = %d\n", v4fmt.reserved[0]);
	}

	int ret = ioctl(fd, VIDIOC_QUERYCAP, &cap);
	if(ret < 0)
		perror("获取功能失败");
	
	printf("drivers:%s\n", cap.driver);//读取驱动名字
	if(cap.capabilities & V4L2_CAP_VIDEO_CAPTURE)
		printf(" 支持视频捕获\n");
	if(cap.capabilities & V4L2_CAP_STREAMING)
		printf(" 支持流读写\n");
	close(fd);
	return 0;
	
}


