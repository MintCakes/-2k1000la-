//NodeOne
// 引入所需头文件，包含各种硬件初始化和操作的函数声明
#include "ls1x.h"
#include "Config.h"
#include "ls1x_gpio.h"
#include "ls1x_latimer.h"
#include "ls1c102_interrupt.h"
#include "iic.h"
#include "oled.h"
#include "dht11.h"
#include "BEEP.h"
#include "key.h"
#include "led.h"
#include "ls1c102_adc.h"
#include "queue.h"
#include "ZigBee.h"

// 定义LED、风扇及温湿度传感器等的引脚定义
#define LED 20
#define LED3_PIN GPIO_PIN_27
#define LED4_PIN GPIO_PIN_26
#define fan GPIO_PIN_37

// 定义全局变量，用于存储温湿度数据和状态标志
char str[50];
static uint16_t temperature;
static uint16_t humidity;
int Flamegas = 0;
int Auto = 1;
unsigned short value;
uint8_t data[9]; // 数据上云平台的数据包

// 主函数入口
int main(int arg, char *args[])
{
    // 初始化系统时钟、GPIO、OLED、按键等硬件设备
    SystemClockInit(); // 时钟等系统配置
    GPIOInit();        // io配置
    OLED_Init();
    KEY_Init();
    EnableInt();                                      // 开总中断
    DL_LN3X_Init(DL_LN3X_NODE, CHANNEL, Network1_Id); // 设置为从机1，设置信道为0x12，网络地址为0x0003
    Queue_Init(&Circular_queue);

    // 配置ADC相关引脚和初始化ADC
    AFIO_RemapConfig(AFIOB, GPIO_Pin_16, 0); // 初始化ADC通道6引脚
    Adc_powerOn();                           // 打开ADC电源
    Adc_open(ADC_CHANNEL_I6);                // 开启ADC通道6

    // 初始化风扇、LED引脚为输出模式
    gpio_set_direction(fan, GPIO_Mode_Out);
    gpio_set_direction(LED3_PIN, GPIO_Mode_Out); // 配置为GPIO输出模式
    gpio_set_direction(LED4_PIN, GPIO_Mode_Out); // 配置为GPIO输出模式
    gpio_set_direction(GPIO_PIN_33, GPIO_Mode_Out);//除湿器控制引脚配置

    // 初始化蜂鸣器和串口
    int FanState = 0;
    gpio_write_pin(LED3_PIN, 1);
    BEEP_Init();
    Uart0_init(9600); // 串口0初始化，io06 io07   串口初始化需要在开启EnableInt之后

    // 初始化DHT11温湿度传感器并显示界面
    while (DHT11_Init()) // 检测是否接入温湿度传感器
    {
        OLED_Show_Str(10, 4, "Sensorless", 16); // OLED显示界面
    }
    OLED_Show_Str(1, 3, "Temp:      ℃", 16); // OLED显示界面
    OLED_Show_Str(1, 6, "Humi:      %RH", 16);

    // 主循环，用于实时采集和处理数据
    while (1)
    {
        // 烟雾检测
        value = Adc_Measure(ADC_CHANNEL_I6); // ADC电压采集  单位：毫伏
        if (value >= 2400)
        {
            OLED_Show_Str(1, 0, "Fire Gases !!", 16);
            BEEP_ON;
            Flamegas = 1; // 可燃气监测标志位
        }
        else
        {
            OLED_Show_Str(1, 0, "No Fire Gases", 16);
            Flamegas = 0;
            BEEP_OFF;
        }

        // 温湿度数据采集和显示
        DHT11_Read_Data(&temperature, &humidity); // 读取温湿度值
        sprintf(str, "%2d", temperature / 10);
        OLED_Show_Str(70, 3, str, 16); // 显示温度
        sprintf(str, "%2d", humidity / 10);
        OLED_Show_Str(70, 6, str, 16); // 显示湿度

        if (humidity >= 800)
        {
            gpio_write_pin(GPIO_PIN_33, 1);//开启除湿
        }
                if (humidity <= 800)
        {
            gpio_write_pin(GPIO_PIN_33, 0);//关闭除湿
        }
        
        // 风扇控制逻辑
        int mode = KEY_Check();
        if (mode == 3)
        {
            gpio_write_pin(LED4_PIN, 0);
            gpio_write_pin(LED3_PIN, 1);
            gpio_write_pin(LED1_PIN, 0);
            gpio_write_pin(LED2_PIN, 0);
            Auto = 1;
        }
        if (mode == 4)
        {
            gpio_write_pin(LED3_PIN, 0);
            gpio_write_pin(LED4_PIN, 1);
            Auto = 0;
        }

        // 自动模式下的风扇控制
        if (Auto == 1)
        {
            if (Flamegas == 1)
            {
                FanState = 1;
                gpio_write_pin(fan, 1);
                delay_ms(700);
            }
            else
            {
                FanState = 0;
                gpio_write_pin(fan, 0);
                delay_ms(300);
            }
        }
        // 手动模式下的风扇控制
        if (Auto == 0)
        {
            if (mode == 1)
            {
                gpio_write_pin(LED2_PIN, 0);
                gpio_write_pin(LED1_PIN, 1);
                gpio_write_pin(fan, 1);
                delay_ms(100);
                gpio_write_pin(LED2_PIN, 0);
                gpio_write_pin(LED1_PIN, 1);
            }
            else if (mode == 2)
            {
                gpio_write_pin(fan, 0);
                delay_ms(100);
                gpio_write_pin(LED2_PIN, 1);
                gpio_write_pin(LED1_PIN, 0);
            }
        }

        // 数据包整理
        data[0] = 0x02;
        data[1] = temperature / 256;
        data[2] = temperature % 256;
        data[3] = humidity / 256;
        data[4] = humidity % 256;
        data[5] = Flamegas;

        delay_ms(222);
        DL_LN3X_Send(data, 9, ZIGBEE_RX_NODE); // 发送数据包
    }

    return 0;
}